The way we suppose to save the files is not clear to me.
In my system the command to run all program for example is - 
C:\Users\HPC\.jdks\openjdk-23\bin\java.exe "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA 2024.2.3\lib\idea_rt.jar=56621:C:\Program Files\JetBrains\IntelliJ IDEA 2024.2.3\bin" -Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -classpath C:\Zohar\University\JavaAdvanced\Maman11\ExAHitStampGame\out\production\ExAHitStampGame Maman11.ExAHitStampGame.HitStampGame

Its contain the wanted jars and set the class path and the total package name.
