package Maman12.ExAAnimals.Attributes;

public enum Color {
    BLACK,
    WHITE,
    RED,
    GREEN
}
