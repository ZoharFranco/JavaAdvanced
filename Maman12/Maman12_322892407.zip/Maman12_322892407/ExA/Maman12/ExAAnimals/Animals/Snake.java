package Maman12.ExAAnimals.Animals;

import Maman12.ExAAnimals.AnimalTypes.Reptile;
import Maman12.ExAAnimals.Attributes.Color;
import Maman12.ExAAnimals.Attributes.Owner;

public class Snake extends Reptile {
    public Snake(String name, int age, Color color) {
        super(name, age, color);
    }
}
